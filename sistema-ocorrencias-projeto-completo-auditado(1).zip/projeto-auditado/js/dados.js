/* ==========================================================
   dados.js — Dados do protótipo
   Etapa 2: unidades territoriais e polos.
   Etapa 3: motivos da ocorrência.
   Não há banco de dados nesta fase.
   ========================================================== */
"use strict";

const TOTAL_UNIDADES = 28;
const TOTAL_POLOS = 168;

function criarLista(prefixo, total) {
  const lista = [];
  for (let numero = 1; numero <= total; numero++) {
    lista.push(Object.freeze({ id: numero, nome: prefixo + " " + numero }));
  }
  return Object.freeze(lista);
}

// Motivos da ocorrência. O "id" é o valor estável que será gravado
// (futuramente no banco); o "nome" é apenas o texto exibido.
const MOTIVOS = Object.freeze([
  Object.freeze({ id: "comunicacao", nome: "Comunicação" }),
  Object.freeze({ id: "prazo", nome: "Prazo" }),
  Object.freeze({ id: "equipe_aplicacao", nome: "Equipe de aplicação" }),
  Object.freeze({ id: "logistica", nome: "Logística" }),
  Object.freeze({ id: "material_aplicacao", nome: "Material de aplicação" }),
  Object.freeze({ id: "procedimento_aplicacao", nome: "Procedimento de aplicação" }),
  Object.freeze({ id: "atendimento_especializado", nome: "Atendimento especializado" }),
  Object.freeze({ id: "polo", nome: "Polo" }),
  Object.freeze({ id: "seguranca_sigilo", nome: "Segurança/Sigilo" }),
  Object.freeze({ id: "financeiro", nome: "Financeiro" }),
  Object.freeze({ id: "outros_fatos_relevantes", nome: "Outros fatos relevantes" })
]);

const DADOS = Object.freeze({
  unidades: criarLista("Unidade", TOTAL_UNIDADES), // Unidade 1 até Unidade 28
  polos: criarLista("Polo", TOTAL_POLOS),          // Polo 1 até Polo 168
  motivos: MOTIVOS
});
