/* ==========================================================
   script.js — Telas e fluxos dos coordenadores
   Etapa 1: tela inicial.
   Etapa 2: seleção de unidade e polo.
   Etapa 3: abre o registro de ocorrência (registro.js).
   ========================================================== */
"use strict";

(function () {
  // Configuração da seleção de cada tipo de coordenador.
  var SELECOES = {
    territorial: {
      titulo: "Unidade territorial",
      texto: "Selecione a sua unidade para continuar.",
      rotulo: "Unidade",
      vazio: "Selecione uma unidade",
      erro: "Selecione uma unidade para continuar.",
      lista: DADOS.unidades
    },
    polo: {
      titulo: "Polo",
      texto: "Selecione o seu polo para continuar.",
      rotulo: "Polo",
      vazio: "Selecione um polo",
      erro: "Selecione um polo para continuar.",
      lista: DADOS.polos
    },
    subcoordenador: {
      titulo: "Polo do subcoordenador",
      texto: "Selecione o polo em que você atua para continuar.",
      rotulo: "Polo",
      vazio: "Selecione um polo",
      erro: "Selecione um polo para continuar.",
      lista: DADOS.polos
    }
  };

  // Estado em memória (some ao recarregar a página; não há armazenamento).
  var estado = { perfil: null, selecionado: null };

  var telaInicial = document.getElementById("tela-inicial");
  var telaSelecao = document.getElementById("tela-selecao");
  var avisoInicial = document.getElementById("aviso");
  var avisoSelecao = document.getElementById("aviso-selecao");
  var titulo = document.getElementById("titulo-selecao");
  var texto = document.getElementById("texto-selecao");
  var rotulo = document.getElementById("rotulo-selecao");
  var campo = document.getElementById("campo-selecao");
  var erro = document.getElementById("erro-selecao");
  var botaoVoltar = document.getElementById("botao-voltar");
  var botaoContinuar = document.getElementById("botao-continuar");
  var cards = document.querySelectorAll("[data-perfil]");

  function temSelecao(chave) {
    return Object.prototype.hasOwnProperty.call(SELECOES, chave);
  }

  // Procura o item na lista oficial; nunca confia no valor bruto do campo.
  function buscarItem(lista, valor) {
    if (!/^[0-9]{1,3}$/.test(valor)) {
      return null;
    }
    var id = Number(valor);
    for (var i = 0; i < lista.length; i++) {
      if (lista[i].id === id) {
        return lista[i];
      }
    }
    return null;
  }

  function limparMensagens() {
    erro.textContent = "";
    erro.hidden = true;
    avisoSelecao.textContent = "";
    avisoSelecao.hidden = true;
  }

  function montarOpcoes(config) {
    campo.textContent = "";
    var vazia = document.createElement("option");
    vazia.value = "";
    vazia.textContent = config.vazio;
    campo.appendChild(vazia);
    config.lista.forEach(function (item) {
      var opcao = document.createElement("option");
      opcao.value = String(item.id);
      opcao.textContent = item.nome;
      campo.appendChild(opcao);
    });
    campo.value = "";
  }

  function abrirSelecao(chave) {
    var config = SELECOES[chave];
    estado.perfil = chave;
    estado.selecionado = null;

    titulo.textContent = config.titulo;
    texto.textContent = config.texto;
    rotulo.textContent = config.rotulo;
    montarOpcoes(config);
    botaoContinuar.disabled = true;
    limparMensagens();

    telaInicial.hidden = true;
    telaSelecao.hidden = false;
    campo.focus();
  }

  function voltarParaInicio() {
    estado.perfil = null;
    estado.selecionado = null;
    limparMensagens();
    telaSelecao.hidden = true;
    telaInicial.hidden = false;
    avisoInicial.hidden = true;
    avisoInicial.textContent = "";
  }

  function aoMudarSelecao() {
    var config = SELECOES[estado.perfil];
    var item = config ? buscarItem(config.lista, campo.value) : null;
    estado.selecionado = item;
    botaoContinuar.disabled = item === null;
    limparMensagens();
  }

  function continuar() {
    var config = SELECOES[estado.perfil];
    var item = config ? buscarItem(config.lista, campo.value) : null;

    if (item === null) {
      estado.selecionado = null;
      botaoContinuar.disabled = true;
      erro.textContent = config ? config.erro : "Seleção inválida.";
      erro.hidden = false;
      return;
    }

    estado.selecionado = item;
    telaSelecao.hidden = true;
    var aberto = Registro.abrir(
      { perfil: estado.perfil, origem: { tipo: Permissoes.origemDoPerfil(estado.perfil), id: item.id } },
      { aoVoltar: reabrirSelecao, aoSair: voltarParaInicio }
    );
    if (!aberto) {
      telaSelecao.hidden = false;
      erro.textContent = "Não foi possível abrir o registro para este perfil.";
      erro.hidden = false;
    }
  }

  function reabrirSelecao() {
    telaSelecao.hidden = false;
    campo.focus();
  }

  function escolherPerfil(chave) {
    if (temSelecao(chave)) {
      abrirSelecao(chave);
      return;
    }
    if (!Permissoes.existe(chave)) {
      return;
    }
    // Administrador: comportamento mantido; área criada na Etapa 4.
    avisoInicial.textContent =
      "Perfil escolhido: " + Permissoes.rotulo(chave) + ". A próxima tela será criada na Etapa 4.";
    avisoInicial.hidden = false;
  }

  cards.forEach(function (card) {
    card.addEventListener("click", function () {
      escolherPerfil(card.getAttribute("data-perfil"));
    });
  });

  campo.addEventListener("change", aoMudarSelecao);
  botaoContinuar.addEventListener("click", continuar);
  botaoVoltar.addEventListener("click", voltarParaInicio);
})();
