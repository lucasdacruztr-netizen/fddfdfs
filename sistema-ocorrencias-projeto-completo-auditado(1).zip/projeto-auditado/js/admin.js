/* ==========================================================
   admin.js — Área do Administrador
   Etapa 1: ainda sem funcionalidades.
   A área administrativa será criada na Etapa 4.
   ========================================================== */
"use strict";
